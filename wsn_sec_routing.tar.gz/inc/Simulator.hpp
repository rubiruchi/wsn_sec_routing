#ifndef __SIMULATOR_HPP__
#define __SIMULATOR_HPP__

#include <vector>
#include <thread>
#include <condition_variable>

#include "BaseStation.hpp"
#include "SensorNode.hpp"

class Simulator
{
private:
    // Vector of thread pointers to instances of node threads,
    // including cluster head(s) and other nodes.
    std::vector<std::thread *> thrNodes;
    std::condition_variable frmSyncCv;
    std::atomic<int> frmDone();
    long globalTick;
public:
    Simulator();
    ~Simulator();
    void addNode(SensorNode &node);
    void run(long stopTime);
};

#endif /*__SIMULATOR_HPP__*/
