#ifndef __SENSORNODE_HPP__
#define __SENSORNODE_HPP__

#include <vector>
#include <thread>
#include <condition_variable>

#include <iostream>
#include <cstdarg>

class SensorNode
{
private:
    std::condition_variable *frmSyncCv;
protected:
    void print(...);
public:
    SensorNode();
    ~SensorNode();
    virtual void runRound() = 0;
    void run();
};

#endif /*__SENSORNODE_HPP__*/
