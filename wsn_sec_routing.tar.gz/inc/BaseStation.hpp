#ifndef __BASESTATION_HPP__
#define __BASESTATION_HPP__



#endif /*__BASESTATION_HPP__*/