#include <iostream>
#include "SensorNode.hpp"
#include "Simulator.hpp"

int main()
{
    SensorNode s();
    Simulator sim();
    std::cout << "Hi" << std::endl;
    return 0;
}