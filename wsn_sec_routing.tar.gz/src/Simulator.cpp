#include "Simulator.hpp"

Simulator::Simulator()
{
    thrNodes.clear();
    globalTick = 0;
}

Simulator::~Simulator()
{
    for (auto thr : thrNodes) {
        thr->join();
        delete thr;
    }
    thrNodes.clear();
}

void 
Simulator::addNode(SensorNode &node)
{
    
}

void
Simulator::run(long stopTime)
{
    
}